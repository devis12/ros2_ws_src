^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package dummy_robot_bringup
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.9.3 (2020-06-01)
------------------

0.9.2 (2020-05-26)
------------------

0.9.1 (2020-05-12)
------------------

0.9.0 (2020-04-30)
------------------
* Add XML and YAML launch scripts for dummy_robot_bringup (`#440 <https://github.com/ros2/demos/issues/440>`_)
* Switch dummy_robot_bringup to use parameter for rsp. (`#426 <https://github.com/ros2/demos/issues/426>`_)
* Switch back to robot_state_publisher for the node name.
* Switch dummy_robot_bringup to use parameter for rsp.
* Contributors: Chris Lalancette, Jacob Perron, p-vega

0.8.4 (2019-11-19)
------------------

0.8.3 (2019-11-11)
------------------

0.8.2 (2019-11-08)
------------------
* Remove unnecessary dependency on ros2run (`#413 <https://github.com/ros2/demos/issues/413>`_)
* Contributors: Michel Hidalgo

0.8.1 (2019-10-23)
------------------

0.8.0 (2019-09-26)
------------------

0.7.6 (2019-05-30)
------------------

0.7.5 (2019-05-29)
------------------
* Replace mesh with box (`#349 <https://github.com/ros2/demos/issues/349>`_)
* Contributors: Karsten Knese

0.7.4 (2019-05-20)
------------------

0.7.3 (2019-05-10)
------------------

0.7.2 (2019-05-08)
------------------

0.7.1 (2019-04-26)
------------------

0.7.0 (2019-04-14)
------------------

0.6.2 (2019-01-15)
------------------

0.6.1 (2018-12-13)
------------------

0.6.0 (2018-12-07)
------------------
* Added missing launch_ros exec dependency (`#277 <https://github.com/ros2/demos/issues/277>`_)
* Contributors: Mikael Arguedas

0.5.1 (2018-06-28)
------------------

0.5.0 (2018-06-27)
------------------
* Convert launch files to new launch style. (`#262 <https://github.com/ros2/demos/issues/262>`_)
* Contributors: Kevin Allen
